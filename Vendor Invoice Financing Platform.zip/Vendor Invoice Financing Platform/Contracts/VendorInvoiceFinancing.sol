// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IERC20Like {
    function transfer(address to, uint256 amount) external returns (bool);

    function transferFrom(address from, address to, uint256 amount) external returns (bool);
}

abstract contract SimpleReentrancyGuard {
    uint256 private constant _NOT_ENTERED = 1;
    uint256 private constant _ENTERED = 2;
    uint256 private _status = _NOT_ENTERED;

    modifier nonReentrant() {
        require(_status == _NOT_ENTERED, "REENTRANT_CALL");
        _status = _ENTERED;
        _;
        _status = _NOT_ENTERED;
    }
}

contract VendorInvoiceFinancing is SimpleReentrancyGuard {
    enum ParticipantType {
        Supplier,
        Buyer,
        Financier,
        Admin
    }

    enum InvoiceStatus {
        PendingBuyerConfirmation,
        OpenForFunding,
        Funded,
        Settled,
        Cancelled,
        Flagged
    }

    struct Invoice {
        bytes32 externalInvoiceId;
        address supplier;
        address buyer;
        address financier;
        uint128 principalAmount;
        uint16 discountBps;
        uint64 dueDate;
        uint64 createdAt;
        uint64 buyerConfirmedAt;
        uint64 fundedAt;
        uint64 settledAt;
        string documentHash;
        InvoiceStatus status;
    }

    IERC20Like public immutable settlementToken;
    address public owner;
    address public treasury;
    uint16 public platformFeeBps;
    uint256 public invoiceCount;

    mapping(address => bool) public suppliers;
    mapping(address => bool) public buyers;
    mapping(address => bool) public financiers;
    mapping(address => bool) public admins;
    mapping(uint256 => Invoice) private invoices;
    mapping(bytes32 => bool) public usedExternalInvoiceIds;
    mapping(uint256 => string) public flagReasons;

    event ParticipantApprovalUpdated(address indexed account, ParticipantType indexed role, bool approved);
    event TreasuryUpdated(address indexed oldTreasury, address indexed newTreasury);
    event PlatformFeeUpdated(uint16 oldFeeBps, uint16 newFeeBps);
    event InvoiceCreated(
        uint256 indexed invoiceId,
        bytes32 indexed externalInvoiceId,
        address indexed supplier,
        address buyer,
        uint256 principalAmount,
        uint64 dueDate
    );
    event InvoiceConfirmed(uint256 indexed invoiceId, address indexed buyer, uint64 confirmedAt);
    event InvoiceFunded(
        uint256 indexed invoiceId,
        address indexed financier,
        uint256 supplierAdvance,
        uint256 platformFee
    );
    event InvoiceSettled(
        uint256 indexed invoiceId,
        address indexed buyer,
        address indexed financier,
        uint256 repaymentAmount
    );
    event InvoiceCancelled(uint256 indexed invoiceId, address indexed cancelledBy);
    event InvoiceFlagged(uint256 indexed invoiceId, address indexed flaggedBy, string reason);
    event InvoiceFlagResolved(uint256 indexed invoiceId, InvoiceStatus nextStatus);

    modifier onlyOwner() {
        require(msg.sender == owner, "ONLY_OWNER");
        _;
    }

    modifier onlyAdmin() {
        require(admins[msg.sender], "ONLY_ADMIN");
        _;
    }

    modifier onlyApprovedSupplier() {
        require(suppliers[msg.sender], "ONLY_SUPPLIER");
        _;
    }

    modifier onlyApprovedFinancier() {
        require(financiers[msg.sender], "ONLY_FINANCIER");
        _;
    }

    modifier invoiceExists(uint256 invoiceId) {
        require(invoiceId < invoiceCount, "INVOICE_NOT_FOUND");
        _;
    }

    modifier onlyInvoiceBuyer(uint256 invoiceId) {
        require(msg.sender == invoices[invoiceId].buyer, "ONLY_INVOICE_BUYER");
        _;
    }

    modifier onlyInvoiceSupplier(uint256 invoiceId) {
        require(msg.sender == invoices[invoiceId].supplier, "ONLY_INVOICE_SUPPLIER");
        _;
    }

    constructor(address settlementTokenAddress, address treasuryAddress) {
        require(settlementTokenAddress != address(0), "INVALID_TOKEN");
        require(treasuryAddress != address(0), "INVALID_TREASURY");

        settlementToken = IERC20Like(settlementTokenAddress);
        owner = msg.sender;
        treasury = treasuryAddress;
        platformFeeBps = 50;
        admins[msg.sender] = true;
    }

    function setParticipantApproval(address account, ParticipantType role, bool approved) external onlyAdmin {
        require(account != address(0), "INVALID_ACCOUNT");

        if (role == ParticipantType.Supplier) {
            suppliers[account] = approved;
        } else if (role == ParticipantType.Buyer) {
            buyers[account] = approved;
        } else if (role == ParticipantType.Financier) {
            financiers[account] = approved;
        } else {
            admins[account] = approved;
        }

        emit ParticipantApprovalUpdated(account, role, approved);
    }

    function setTreasury(address newTreasury) external onlyOwner {
        require(newTreasury != address(0), "INVALID_TREASURY");

        address oldTreasury = treasury;
        treasury = newTreasury;

        emit TreasuryUpdated(oldTreasury, newTreasury);
    }

    function setPlatformFeeBps(uint16 newFeeBps) external onlyOwner {
        require(newFeeBps <= 500, "FEE_TOO_HIGH");

        uint16 oldFeeBps = platformFeeBps;
        platformFeeBps = newFeeBps;

        emit PlatformFeeUpdated(oldFeeBps, newFeeBps);
    }

    function createInvoice(
        bytes32 externalInvoiceId,
        address buyer,
        uint128 principalAmount,
        uint16 discountBps,
        uint64 dueDate,
        string calldata documentHash
    ) external onlyApprovedSupplier returns (uint256 invoiceId) {
        require(buyers[buyer], "BUYER_NOT_APPROVED");
        require(externalInvoiceId != bytes32(0), "INVALID_EXTERNAL_ID");
        require(!usedExternalInvoiceIds[externalInvoiceId], "DUPLICATE_INVOICE_ID");
        require(principalAmount > 0, "INVALID_AMOUNT");
        require(discountBps > 0 && discountBps <= 3000, "INVALID_DISCOUNT");
        require(uint256(discountBps) + uint256(platformFeeBps) < 10000, "BAD_ECONOMICS");
        require(dueDate > block.timestamp + 1 days, "DUE_DATE_TOO_SOON");
        require(bytes(documentHash).length > 0, "DOCUMENT_HASH_REQUIRED");

        invoiceId = invoiceCount;
        invoices[invoiceId] = Invoice({
            externalInvoiceId: externalInvoiceId,
            supplier: msg.sender,
            buyer: buyer,
            financier: address(0),
            principalAmount: principalAmount,
            discountBps: discountBps,
            dueDate: dueDate,
            createdAt: uint64(block.timestamp),
            buyerConfirmedAt: 0,
            fundedAt: 0,
            settledAt: 0,
            documentHash: documentHash,
            status: InvoiceStatus.PendingBuyerConfirmation
        });

        usedExternalInvoiceIds[externalInvoiceId] = true;
        invoiceCount += 1;

        emit InvoiceCreated(invoiceId, externalInvoiceId, msg.sender, buyer, principalAmount, dueDate);
    }

    function confirmInvoice(uint256 invoiceId)
        external
        invoiceExists(invoiceId)
        onlyInvoiceBuyer(invoiceId)
    {
        Invoice storage invoice = invoices[invoiceId];
        require(invoice.status == InvoiceStatus.PendingBuyerConfirmation, "INVALID_STATUS");

        invoice.buyerConfirmedAt = uint64(block.timestamp);
        invoice.status = InvoiceStatus.OpenForFunding;

        emit InvoiceConfirmed(invoiceId, msg.sender, uint64(block.timestamp));
    }

    function quoteFunding(uint256 invoiceId)
        public
        view
        invoiceExists(invoiceId)
        returns (uint256 supplierAdvance, uint256 platformFee, uint256 financierRepayment)
    {
        Invoice storage invoice = invoices[invoiceId];
        uint256 principal = uint256(invoice.principalAmount);
        uint256 financierDiscount = (principal * invoice.discountBps) / 10000;
        platformFee = (principal * platformFeeBps) / 10000;
        supplierAdvance = principal - financierDiscount - platformFee;
        financierRepayment = principal;
    }

    function fundInvoice(uint256 invoiceId)
        external
        nonReentrant
        invoiceExists(invoiceId)
        onlyApprovedFinancier
    {
        Invoice storage invoice = invoices[invoiceId];
        require(invoice.status == InvoiceStatus.OpenForFunding, "INVOICE_NOT_OPEN");
        require(invoice.financier == address(0), "ALREADY_FUNDED");
        require(msg.sender != invoice.supplier && msg.sender != invoice.buyer, "ROLE_CONFLICT");

        (uint256 supplierAdvance, uint256 platformFee, ) = quoteFunding(invoiceId);

        invoice.financier = msg.sender;
        invoice.fundedAt = uint64(block.timestamp);
        invoice.status = InvoiceStatus.Funded;

        require(
            settlementToken.transferFrom(msg.sender, invoice.supplier, supplierAdvance),
            "SUPPLIER_TRANSFER_FAILED"
        );

        if (platformFee > 0) {
            require(
                settlementToken.transferFrom(msg.sender, treasury, platformFee),
                "TREASURY_TRANSFER_FAILED"
            );
        }

        emit InvoiceFunded(invoiceId, msg.sender, supplierAdvance, platformFee);
    }

    function settleInvoice(uint256 invoiceId)
        external
        nonReentrant
        invoiceExists(invoiceId)
        onlyInvoiceBuyer(invoiceId)
    {
        Invoice storage invoice = invoices[invoiceId];
        require(invoice.status == InvoiceStatus.Funded, "NOT_FUNDED");

        invoice.status = InvoiceStatus.Settled;
        invoice.settledAt = uint64(block.timestamp);

        require(
            settlementToken.transferFrom(msg.sender, invoice.financier, invoice.principalAmount),
            "SETTLEMENT_TRANSFER_FAILED"
        );

        emit InvoiceSettled(invoiceId, msg.sender, invoice.financier, invoice.principalAmount);
    }

    function cancelInvoice(uint256 invoiceId)
        external
        invoiceExists(invoiceId)
        onlyInvoiceSupplier(invoiceId)
    {
        Invoice storage invoice = invoices[invoiceId];
        require(invoice.financier == address(0), "ALREADY_FUNDED");
        require(
            invoice.status == InvoiceStatus.PendingBuyerConfirmation ||
                invoice.status == InvoiceStatus.OpenForFunding ||
                invoice.status == InvoiceStatus.Flagged,
            "INVALID_STATUS"
        );

        invoice.status = InvoiceStatus.Cancelled;

        emit InvoiceCancelled(invoiceId, msg.sender);
    }

    function flagInvoice(uint256 invoiceId, string calldata reason) external invoiceExists(invoiceId) {
        Invoice storage invoice = invoices[invoiceId];
        bool isStakeholder = msg.sender == invoice.supplier ||
            msg.sender == invoice.buyer ||
            msg.sender == invoice.financier ||
            admins[msg.sender];

        require(isStakeholder, "NOT_AUTHORIZED");
        require(invoice.status != InvoiceStatus.Settled, "ALREADY_SETTLED");
        require(invoice.status != InvoiceStatus.Cancelled, "ALREADY_CANCELLED");
        require(bytes(reason).length > 0, "REASON_REQUIRED");

        invoice.status = InvoiceStatus.Flagged;
        flagReasons[invoiceId] = reason;

        emit InvoiceFlagged(invoiceId, msg.sender, reason);
    }

    function resolveFlag(uint256 invoiceId, InvoiceStatus nextStatus)
        external
        onlyAdmin
        invoiceExists(invoiceId)
    {
        Invoice storage invoice = invoices[invoiceId];
        require(invoice.status == InvoiceStatus.Flagged, "NOT_FLAGGED");
        require(
            nextStatus == InvoiceStatus.PendingBuyerConfirmation ||
                nextStatus == InvoiceStatus.OpenForFunding ||
                nextStatus == InvoiceStatus.Funded ||
                nextStatus == InvoiceStatus.Cancelled,
            "INVALID_NEXT_STATUS"
        );

        if (nextStatus == InvoiceStatus.PendingBuyerConfirmation) {
            require(invoice.buyerConfirmedAt == 0, "BUYER_ALREADY_CONFIRMED");
        }

        if (nextStatus == InvoiceStatus.OpenForFunding) {
            require(invoice.financier == address(0), "HAS_FUNDING");
        }

        if (nextStatus == InvoiceStatus.Funded) {
            require(invoice.financier != address(0), "NO_FINANCIER");
        }

        invoice.status = nextStatus;
        delete flagReasons[invoiceId];

        emit InvoiceFlagResolved(invoiceId, nextStatus);
    }

    function getInvoice(uint256 invoiceId)
        external
        view
        invoiceExists(invoiceId)
        returns (Invoice memory)
    {
        return invoices[invoiceId];
    }
}
