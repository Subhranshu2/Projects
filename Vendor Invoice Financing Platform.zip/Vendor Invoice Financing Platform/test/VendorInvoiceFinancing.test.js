const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("VendorInvoiceFinancing", function () {
  async function deployFixture() {
    const [owner, supplier, buyer, financier, treasury] = await ethers.getSigners();

    const MockUSDC = await ethers.getContractFactory("MockUSDC");
    const mockUsdc = await MockUSDC.deploy();
    await mockUsdc.waitForDeployment();

    const Financing = await ethers.getContractFactory("VendorInvoiceFinancing");
    const financing = await Financing.deploy(await mockUsdc.getAddress(), treasury.address);
    await financing.waitForDeployment();

    await financing.connect(owner).setParticipantApproval(supplier.address, 0, true);
    await financing.connect(owner).setParticipantApproval(buyer.address, 1, true);
    await financing.connect(owner).setParticipantApproval(financier.address, 2, true);

    await mockUsdc.mint(buyer.address, 2_000_000_000n);
    await mockUsdc.mint(financier.address, 2_000_000_000n);

    return { financing, mockUsdc, supplier, buyer, financier, treasury };
  }

  it("walks an invoice from creation to settlement", async function () {
    const { financing, mockUsdc, supplier, buyer, financier, treasury } = await deployFixture();
    const dueDate = BigInt(Math.floor(Date.now() / 1000) + 30 * 24 * 60 * 60);
    const externalInvoiceId = ethers.id("INV-2026-0001");

    await financing
      .connect(supplier)
      .createInvoice(externalInvoiceId, buyer.address, 1_000_000, 300, dueDate, "ipfs://invoice-1");

    await financing.connect(buyer).confirmInvoice(0);

    const [supplierAdvance, platformFee, repaymentAmount] = await financing.quoteFunding(0);
    expect(supplierAdvance).to.equal(965_000n);
    expect(platformFee).to.equal(5_000n);
    expect(repaymentAmount).to.equal(1_000_000n);

    const initialFinancierBalance = await mockUsdc.balanceOf(financier.address);

    await mockUsdc.connect(financier).approve(financing.target, supplierAdvance + platformFee);
    await financing.connect(financier).fundInvoice(0);

    expect(await mockUsdc.balanceOf(supplier.address)).to.equal(supplierAdvance);
    expect(await mockUsdc.balanceOf(treasury.address)).to.equal(platformFee);

    await mockUsdc.connect(buyer).approve(financing.target, repaymentAmount);
    await financing.connect(buyer).settleInvoice(0);

    const invoice = await financing.getInvoice(0);
    expect(invoice.status).to.equal(3n);
    expect(await mockUsdc.balanceOf(financier.address)).to.equal(
      initialFinancierBalance - supplierAdvance - platformFee + repaymentAmount
    );
  });

  it("blocks duplicate invoice ids and supports flag resolution", async function () {
    const { financing, supplier, buyer } = await deployFixture();
    const dueDate = BigInt(Math.floor(Date.now() / 1000) + 21 * 24 * 60 * 60);
    const externalInvoiceId = ethers.id("INV-2026-0002");

    await financing
      .connect(supplier)
      .createInvoice(externalInvoiceId, buyer.address, 500_000, 250, dueDate, "ipfs://invoice-2");

    await expect(
      financing
        .connect(supplier)
        .createInvoice(externalInvoiceId, buyer.address, 550_000, 250, dueDate, "ipfs://invoice-duplicate")
    ).to.be.revertedWith("DUPLICATE_INVOICE_ID");

    await financing.connect(buyer).confirmInvoice(0);
    await financing.connect(buyer).flagInvoice(0, "Mismatch between PO and invoice amount");

    const flaggedInvoice = await financing.getInvoice(0);
    expect(flaggedInvoice.status).to.equal(5n);
    expect(await financing.flagReasons(0)).to.equal("Mismatch between PO and invoice amount");

    await financing.resolveFlag(0, 1);

    const reopenedInvoice = await financing.getInvoice(0);
    expect(reopenedInvoice.status).to.equal(1n);
  });
});
