import crypto from "crypto";

export function buildUploadRecord({ invoiceId, fileName, uploadedBy }) {
  const seed = `${invoiceId}:${fileName}:${uploadedBy}`;
  const digest = crypto.createHash("sha256").update(seed).digest("hex");
  const shortHash = digest.slice(0, 32);

  return {
    hash: shortHash,
    url: `ipfs://${shortHash}`,
    uploadedAt: new Date().toISOString()
  };
}
