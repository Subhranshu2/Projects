import cors from "cors";
import express from "express";
import invoicesRouter from "./routes/invoices.js";

const app = express();

app.use(cors());
app.use(express.json());

app.get("/health", (_req, res) => {
  res.json({
    status: "ok",
    service: "vendor-invoice-financing-api"
  });
});

app.use("/api/invoices", invoicesRouter);

export default app;
