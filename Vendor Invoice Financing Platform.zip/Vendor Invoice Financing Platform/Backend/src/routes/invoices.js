import { Router } from "express";
import { addRiskFlag, getInvoice, listInvoices, upsertInvoice } from "../repositories/invoiceRepository.js";
import { buildUploadRecord } from "../services/documentStore.js";

const router = Router();

router.get("/", (_req, res) => {
  res.json({ items: listInvoices() });
});

router.post("/", (req, res) => {
  const { externalInvoiceId, supplierName, buyerName, principalAmount, dueDate } = req.body;

  if (!externalInvoiceId || !supplierName || !buyerName || !principalAmount || !dueDate) {
    return res.status(400).json({ error: "missing required invoice fields" });
  }

  const invoice = {
    externalInvoiceId,
    supplierName,
    buyerName,
    principalAmount: Number(principalAmount),
    dueDate,
    status: "DRAFTED_OFF_CHAIN",
    documentHash: null,
    riskFlags: []
  };

  upsertInvoice(invoice);
  return res.status(201).json(invoice);
});

router.post("/:invoiceId/upload-proof", (req, res) => {
  const invoice = getInvoice(req.params.invoiceId);

  if (!invoice) {
    return res.status(404).json({ error: "invoice not found" });
  }

  const upload = buildUploadRecord({
    invoiceId: req.params.invoiceId,
    fileName: req.body.fileName || "invoice.pdf",
    uploadedBy: req.body.uploadedBy || "ops@company.local"
  });

  invoice.documentHash = upload.url;
  invoice.lastUpload = upload;
  upsertInvoice(invoice);

  return res.json(upload);
});

router.post("/:invoiceId/flag", (req, res) => {
  const note = req.body.note || "manual operations review requested";
  const invoice = addRiskFlag(req.params.invoiceId, note);

  if (!invoice) {
    return res.status(404).json({ error: "invoice not found" });
  }

  return res.json(invoice);
});

export default router;
