const invoices = new Map([
  [
    "INV-2026-0001",
    {
      externalInvoiceId: "INV-2026-0001",
      supplierName: "Northline Components",
      buyerName: "BluePeak Retail",
      principalAmount: 125000,
      dueDate: "2026-04-30",
      status: "PENDING_BUYER_CONFIRMATION",
      documentHash: "ipfs://QmNorthline1",
      riskFlags: []
    }
  ],
  [
    "INV-2026-0002",
    {
      externalInvoiceId: "INV-2026-0002",
      supplierName: "Delta Med Supply",
      buyerName: "Harbor Hospital Network",
      principalAmount: 840000,
      dueDate: "2026-05-10",
      status: "FLAGGED",
      documentHash: "ipfs://QmDelta2",
      riskFlags: ["duplicate PO number from ERP sync"]
    }
  ]
]);

export function listInvoices() {
  return Array.from(invoices.values());
}

export function getInvoice(externalInvoiceId) {
  return invoices.get(externalInvoiceId);
}

export function upsertInvoice(invoice) {
  invoices.set(invoice.externalInvoiceId, invoice);
  return invoice;
}

export function addRiskFlag(externalInvoiceId, note) {
  const invoice = invoices.get(externalInvoiceId);

  if (!invoice) {
    return null;
  }

  invoice.riskFlags = [...invoice.riskFlags, note];
  invoice.status = "FLAGGED";
  invoices.set(externalInvoiceId, invoice);

  return invoice;
}
