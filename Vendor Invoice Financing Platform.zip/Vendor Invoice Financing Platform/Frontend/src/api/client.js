const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";

async function request(path, options = {}) {
  const response = await fetch(`${API_URL}${path}`, {
    headers: {
      "Content-Type": "application/json"
    },
    ...options
  });

  if (!response.ok) {
    throw new Error(`API request failed with status ${response.status}`);
  }

  return response.json();
}

export async function fetchInvoices() {
  const payload = await request("/api/invoices");
  return payload.items;
}

export async function createInvoiceDraft(invoice) {
  return request("/api/invoices", {
    method: "POST",
    body: JSON.stringify(invoice)
  });
}

export async function uploadInvoiceProof(invoiceId, payload) {
  return request(`/api/invoices/${invoiceId}/upload-proof`, {
    method: "POST",
    body: JSON.stringify(payload)
  });
}
