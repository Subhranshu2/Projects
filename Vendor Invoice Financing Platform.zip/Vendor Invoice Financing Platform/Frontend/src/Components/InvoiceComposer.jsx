import { useState } from "react";

const initialState = {
  externalInvoiceId: "",
  supplierName: "",
  buyerName: "",
  principalAmount: "",
  dueDate: ""
};

export default function InvoiceComposer({ onCreate }) {
  const [form, setForm] = useState(initialState);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(event) {
    event.preventDefault();
    setSubmitting(true);

    try {
      await onCreate({
        ...form,
        principalAmount: Number(form.principalAmount)
      });
      setForm(initialState);
    } finally {
      setSubmitting(false);
    }
  }

  function updateField(event) {
    const { name, value } = event.target;
    setForm((current) => ({ ...current, [name]: value }));
  }

  return (
    <form className="invoice-composer" onSubmit={handleSubmit}>
      <div className="form-grid">
        <label>
          External Invoice ID
          <input name="externalInvoiceId" value={form.externalInvoiceId} onChange={updateField} required />
        </label>
        <label>
          Supplier Name
          <input name="supplierName" value={form.supplierName} onChange={updateField} required />
        </label>
        <label>
          Buyer Name
          <input name="buyerName" value={form.buyerName} onChange={updateField} required />
        </label>
        <label>
          Principal Amount
          <input
            name="principalAmount"
            min="1"
            step="1"
            type="number"
            value={form.principalAmount}
            onChange={updateField}
            required
          />
        </label>
        <label>
          Due Date
          <input name="dueDate" type="date" value={form.dueDate} onChange={updateField} required />
        </label>
      </div>

      <button className="secondary-button" disabled={submitting} type="submit">
        {submitting ? "Saving draft..." : "Create Draft"}
      </button>
    </form>
  );
}
