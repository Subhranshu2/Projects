function formatCurrency(amount) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0
  }).format(amount);
}

export default function KpiStrip({ invoices }) {
  const totalPrincipal = invoices.reduce((sum, invoice) => sum + Number(invoice.principalAmount || 0), 0);
  const flagged = invoices.filter((invoice) => invoice.status === "FLAGGED").length;
  const waitingBuyer = invoices.filter(
    (invoice) => invoice.status === "PENDING_BUYER_CONFIRMATION"
  ).length;

  return (
    <section className="kpi-strip">
      <article>
        <span>Total pipeline</span>
        <strong>{formatCurrency(totalPrincipal)}</strong>
      </article>
      <article>
        <span>Buyer review queue</span>
        <strong>{waitingBuyer}</strong>
      </article>
      <article>
        <span>Flagged invoices</span>
        <strong>{flagged}</strong>
      </article>
    </section>
  );
}
