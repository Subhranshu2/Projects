export default function WalletPanel({ account, onConnect, walletReady }) {
  return (
    <section className="wallet-panel">
      <div>
        <p className="eyebrow">Operations Console</p>
        <h1>Vendor Invoice Financing</h1>
        <p className="muted">
          Finance approved supplier invoices, track document proofs, and keep funding activity tied to
          an auditable on-chain state machine.
        </p>
      </div>

      <button className="primary-button" disabled={!walletReady} onClick={onConnect}>
        {account ? `Connected: ${account.slice(0, 6)}...${account.slice(-4)}` : "Connect Wallet"}
      </button>
    </section>
  );
}
