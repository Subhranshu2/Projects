export default function InvoiceTable({ invoices, onUploadProof }) {
  return (
    <section className="invoice-table-card">
      <div className="section-head">
        <div>
          <p className="eyebrow">Invoice Queue</p>
          <h2>Operations View</h2>
        </div>
      </div>

      <table className="invoice-table">
        <thead>
          <tr>
            <th>Invoice</th>
            <th>Counterparties</th>
            <th>Amount</th>
            <th>Status</th>
            <th>Document Proof</th>
          </tr>
        </thead>
        <tbody>
          {invoices.map((invoice) => (
            <tr key={invoice.externalInvoiceId}>
              <td>{invoice.externalInvoiceId}</td>
              <td>
                <div>{invoice.supplierName}</div>
                <div className="muted">{invoice.buyerName}</div>
              </td>
              <td>${Number(invoice.principalAmount).toLocaleString("en-US")}</td>
              <td>
                <span className={`status-chip status-${invoice.status.toLowerCase()}`}>
                  {invoice.status.replaceAll("_", " ")}
                </span>
              </td>
              <td>
                <button
                  className="ghost-button"
                  onClick={() =>
                    onUploadProof(invoice.externalInvoiceId, {
                      fileName: `${invoice.externalInvoiceId}.pdf`,
                      uploadedBy: "ops@company.local"
                    })
                  }
                >
                  {invoice.documentHash ? "Refresh proof" : "Upload proof"}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}
