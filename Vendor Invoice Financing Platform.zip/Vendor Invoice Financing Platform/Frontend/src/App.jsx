import { useEffect, useState } from "react";
import { createInvoiceDraft, fetchInvoices, uploadInvoiceProof } from "./api/client";
import InvoiceComposer from "./components/InvoiceComposer";
import InvoiceTable from "./components/InvoiceTable";
import KpiStrip from "./components/KpiStrip";
import WalletPanel from "./components/WalletPanel";
import { walletAvailable } from "./web3/contract";
import "./styles.css";

export default function App() {
  const [invoices, setInvoices] = useState([]);
  const [account, setAccount] = useState("");
  const [error, setError] = useState("");

  async function loadInvoices() {
    try {
      const items = await fetchInvoices();
      setInvoices(items);
      setError("");
    } catch (loadError) {
      setError(loadError.message);
    }
  }

  useEffect(() => {
    loadInvoices();
  }, []);

  async function handleConnectWallet() {
    if (!walletAvailable()) {
      setError("Install MetaMask before using on-chain actions.");
      return;
    }

    const [selectedAccount] = await window.ethereum.request({
      method: "eth_requestAccounts"
    });

    setAccount(selectedAccount || "");
  }

  async function handleCreateDraft(payload) {
    await createInvoiceDraft(payload);
    await loadInvoices();
  }

  async function handleUploadProof(invoiceId, payload) {
    await uploadInvoiceProof(invoiceId, payload);
    await loadInvoices();
  }

  return (
    <main className="app-shell">
      <WalletPanel account={account} onConnect={handleConnectWallet} walletReady={walletAvailable()} />
      <KpiStrip invoices={invoices} />

      <section className="content-grid">
        <div className="panel">
          <p className="eyebrow">Draft New Opportunity</p>
          <h2>Off-Chain Intake</h2>
          <p className="muted">
            Create the invoice draft off-chain first, attach the document proof, then push the hash into the
            contract once compliance clears the deal.
          </p>
          <InvoiceComposer onCreate={handleCreateDraft} />
        </div>

        <div className="panel">
          <p className="eyebrow">Notes</p>
          <h2>Why recruiters will believe this</h2>
          <ul className="notes-list">
            <li>Duplicate invoice IDs are blocked at contract level.</li>
            <li>Proof documents live off-chain and are anchored with hashes.</li>
            <li>There is a flag-and-review path instead of a fake happy path.</li>
          </ul>
        </div>
      </section>

      <InvoiceTable invoices={invoices} onUploadProof={handleUploadProof} />

      {error ? <p className="error-banner">{error}</p> : null}
    </main>
  );
}
