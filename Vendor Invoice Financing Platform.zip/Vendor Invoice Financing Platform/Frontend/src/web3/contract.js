import { BrowserProvider, Contract } from "ethers";

export const invoiceAbi = [
  "function quoteFunding(uint256 invoiceId) view returns (uint256 supplierAdvance, uint256 platformFee, uint256 financierRepayment)",
  "function confirmInvoice(uint256 invoiceId)",
  "function fundInvoice(uint256 invoiceId)",
  "function settleInvoice(uint256 invoiceId)",
  "function flagInvoice(uint256 invoiceId, string reason)",
  "function getInvoice(uint256 invoiceId) view returns (tuple(bytes32 externalInvoiceId,address supplier,address buyer,address financier,uint128 principalAmount,uint16 discountBps,uint64 dueDate,uint64 createdAt,uint64 buyerConfirmedAt,uint64 fundedAt,uint64 settledAt,string documentHash,uint8 status))"
];

export function walletAvailable() {
  return typeof window !== "undefined" && Boolean(window.ethereum);
}

export async function getContract() {
  const contractAddress = import.meta.env.VITE_CONTRACT_ADDRESS;

  if (!walletAvailable()) {
    throw new Error("MetaMask or another injected wallet is required.");
  }

  if (!contractAddress) {
    throw new Error("Missing VITE_CONTRACT_ADDRESS.");
  }

  const provider = new BrowserProvider(window.ethereum);
  const signer = await provider.getSigner();
  return new Contract(contractAddress, invoiceAbi, signer);
}
