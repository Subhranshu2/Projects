const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();

  let stablecoinAddress = process.env.STABLECOIN_ADDRESS;

  if (!stablecoinAddress) {
    const MockUSDC = await hre.ethers.getContractFactory("MockUSDC");
    const mockUsdc = await MockUSDC.deploy();
    await mockUsdc.waitForDeployment();
    stablecoinAddress = await mockUsdc.getAddress();
    console.log("MockUSDC deployed:", stablecoinAddress);
  }

  const treasuryAddress = process.env.TREASURY_ADDRESS || deployer.address;
  const Financing = await hre.ethers.getContractFactory("VendorInvoiceFinancing");
  const financing = await Financing.deploy(stablecoinAddress, treasuryAddress);
  await financing.waitForDeployment();

  console.log("VendorInvoiceFinancing deployed:", await financing.getAddress());
  console.log("Settlement token:", stablecoinAddress);
  console.log("Treasury:", treasuryAddress);
  console.log("Deployer:", deployer.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
