# Architecture Notes

## On-Chain Responsibilities

- role approvals for suppliers, buyers, financiers, and admins
- duplicate invoice prevention via `externalInvoiceId`
- invoice lifecycle state transitions
- funding settlement in stablecoin
- flag and resolution flow for suspicious invoices

## Off-Chain Responsibilities

- invoice document upload and storage
- buyer onboarding and KYC checks
- invoice enrichment data such as ERP identifiers and supplier metadata
- dashboards, notifications, and analytics

## Why split the system this way

Putting raw invoice files, ERP metadata, and operations notes on-chain is expensive and awkward. A more believable company project stores documents off-chain, writes a content hash on-chain, and lets business users work through a conventional API and dashboard.

## Typical Lifecycle

1. Supplier uploads invoice PDF through the API.
2. API returns a document URL or content hash.
3. Supplier creates the on-chain invoice using the returned hash.
4. Buyer confirms the invoice after internal review.
5. Financier funds the invoice against the approved amount.
6. Buyer settles the principal back to the financier.
7. If anything looks wrong, operations can flag the invoice and freeze progress.

## Data Model Notes

- `externalInvoiceId` exists to mirror real ERP invoice references.
- `documentHash` is stored as a string so you can use an IPFS CID or an internal object-store hash.
- `flagReasons` is separate because investigations often evolve independently from the invoice record itself.
