require("@nomicfoundation/hardhat-toolbox");
require("dotenv").config();

const networks = {
  hardhat: {}
};

if (process.env.RPC_URL && process.env.PRIVATE_KEY) {
  networks.sepolia = {
    url: process.env.RPC_URL,
    accounts: [process.env.PRIVATE_KEY]
  };
}

module.exports = {
  solidity: {
    version: "0.8.24",
    settings: {
      optimizer: {
        enabled: true,
        runs: 200
      }
    }
  },
  networks
};
